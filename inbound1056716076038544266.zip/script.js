
const fullname="John Kim Soria";
const loc="Philippines, Bohol";

document.getElementById("fullname").innerHTML=fullname;
document.getElementById("loc").innerHTML=loc;
